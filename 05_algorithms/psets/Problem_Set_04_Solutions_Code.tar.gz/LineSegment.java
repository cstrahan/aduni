public class LineSegment
{
    private String name;
    private Point endpoint1;
    private Point endpoint2;

    //testing...
    public static void main(String[] args)
    {
	Point a = new Point('a', 1, 5);
	Point b = new Point('b', 5, 1);
	Point c = new Point('c', -1, 0);
	Point d = new Point('d', 3, 3);
	LineSegment ab = new LineSegment(a, b);
	LineSegment cd = new LineSegment(d, d);
	System.out.println(intersect(ab, cd));
    }

    public LineSegment(Point p1, Point p2)
    {
	name = "" + p1.getName() + p2.getName();
	endpoint1 = p1;
	endpoint2 = p2;
    }

    public String getName() { return name; }
    public Point[] getEndpoints()
    {
	return new Point[] {endpoint1, endpoint2};
    }

    public double length()
    {
	return Point.distance(endpoint1, endpoint2);
    }

    public double slope()
    {
	return ((endpoint2.getY() - endpoint1.getY())/
		(endpoint2.getX() - endpoint1.getX()));
    }

    /*
      returns true if a and b intersect; false otherwise.
    */
    public static boolean intersect(LineSegment a, LineSegment b)
    {
	if (quickReject(a, b)) return false;
	else return straddle(a, b);	
    }

    /*
      returns true if both a and b straddle each other;
      returns false otherwise.
    */
    public static boolean straddle(LineSegment a, LineSegment b)
    {
	Point a1 = a.endpoint1;
	Point a2 = a.endpoint2;
	Point b1 = b.endpoint1;
	Point b2 = b.endpoint2;

	int bStraddleaVal1 = a1.turnOrient(a2, b1);
	int bStraddleaVal2 = a1.turnOrient(a2, b2);

	int aStraddlebVal1 = b1.turnOrient(b2, a1);
	int aStraddlebVal2 = b1.turnOrient(b2, a2);

	/*
	  ok so the logic here is somewhat tricky.
	  Basically, I would recommend looking in the
	  book p. 890 if you really want to know why
	  this works.
	*/
	if (bStraddleaVal1 * bStraddleaVal2 == -1)
	   {
	       if (aStraddlebVal1 * aStraddlebVal2 <= 0)
		   return true;
	   }
	if (aStraddlebVal1 * aStraddlebVal2 == -1)
	    {
		if (bStraddleaVal1 * bStraddleaVal2 <= 0)
		    return true;
	    }
	if ((a.length() == 0 && aStraddlebVal1 == 0) ||
	    (b.length() == 0 && bStraddleaVal1 == 0))
	    return true;
	else return false;
    }

    /*
      returns false if bounding boxes intersect;
      returns true if bounding boxes do not intersect.
    */
    public static boolean quickReject(LineSegment a, LineSegment b)
    {
	double aLowLeftx = a.endpoint1.getX();
	double aLowLefty = a.endpoint1.getY();
	double aUpRightx = a.endpoint2.getX();
	double aUpRighty = a.endpoint2.getY();

	if (aUpRightx < aLowLeftx)
	    {
		double temp = aLowLeftx;
		aLowLeftx = aUpRightx;
		aUpRightx = temp;
	    }
	if (aUpRighty < aLowLefty)
	    {
		double temp = aLowLefty;
		aLowLefty = aUpRighty;
		aUpRighty = temp;
	    }

	double bLowLeftx = b.endpoint1.getX();
	double bLowLefty = b.endpoint1.getY();
	double bUpRightx = b.endpoint2.getX();
	double bUpRighty = b.endpoint2.getY();

	if (bUpRightx < bLowLeftx)
	    {
		double temp = bLowLeftx;
		bLowLeftx = bUpRightx;
		bUpRightx = temp;
	    }
	if (bUpRighty < bLowLefty)
	    {
		double temp = bLowLefty;
		bLowLefty = bUpRighty;
		bUpRighty = temp;
	    }

	if ((aUpRightx >= bLowLeftx) &&
	    (bUpRightx >= aLowLeftx) &&
	    (aUpRighty >= bLowLefty) &&
	    (bUpRighty >= aLowLefty))
	    return false;
	else return true;
    }
}




