import java.util.*;

public class JarvisConvexHull
{
    public static void main(String[] args)
    {
	Point[] points =
	{
	    new Point('A', 0, 0),
	    new Point('B', -5, -2),
	    new Point('C', -2, -1),
	    new Point('D', -6, 0),
	    new Point('E', -3.5, 1),
	    new Point('F', -4.5, 1.5),
	    new Point('G', -2.5, -5),
	    new Point('H', 1, -2.5),
	    new Point('I', 2.5, .5),
	    new Point('J', -2.2, 2.2)
		};
	convexHull(points);
    }

    public static void convexHull(Point[] pointsArr)
    {
	GrahamScan.findLowestAndSwitch(pointsArr);
	Point lowest = pointsArr[0];
	LinkedList hull = new LinkedList();
	hull.add(lowest);
	Point lastOnHull = lowest;
	while (lastOnHull != lowest || hull.size() < 3)
	    {
		hull.add(pointsArr[findMinAngle(lastOnHull, pointsArr)]);
		lastOnHull = (Point)hull.getLast();
	    }
	hull.removeLast(); // get rid of duplicate starting point
	ListIterator iter = hull.listIterator();
	System.out.println("Points in (Jarvis) Convex Hull:");
	while (iter.hasNext())
	    {
		Point p = (Point)iter.next();
		p.printPoint();
	    }
    }

    public static int findMinAngle(Point a, Point[] pointsArr)
    {
	int minIndex = -1;
	for (int i = 0; i < pointsArr.length; i++)
	    {
		if (a == pointsArr[i]) continue;
		if (minIndex == -1) minIndex = i;
		else
		    {
			int orientVal = a.turnOrient
			    (pointsArr[minIndex], pointsArr[i]);
			if (orientVal == 1) minIndex = i;
			if (orientVal == 0)
			    {
				if (Point.distance(a, pointsArr[i]) <
				    Point.distance(a, pointsArr[minIndex]))
				    minIndex = i;
			    }
		    }
	    }
	return minIndex;
    }
}
