public class Point
{
    private char name = '0';
    private double x = 0;
    private double y = 0;

    public Point(char name, double x, double y)
    {
	this.name = name;
	this.x = x;
	this.y = y;
    }

    public char getName() { return name; }
    public double getX() { return x; }
    public double getY() { return y; }

    public void printPoint()
    {
	System.out.println("Point " + name + ": (" + x + ", " + y + ")");
    }

    public static double distance(Point a, Point b)
    {
	double yDiffSq = Math.pow((b.y - a.y), 2);
	double xDiffSq = Math.pow((b.x - a.x), 2);
	double dist = Math.sqrt(yDiffSq + xDiffSq);
	return dist;
    }

    /*
      returns 1 if movement from line this-b to line this-c is clockwise;
      returns -1 if movement from line this-b to line this-c is counterclockwise;
      returns 0 if this-b-c are on the same line.
    */
    public int turnOrient(Point b, Point c)
    {
	double bCross = (c.x - this.x) * (b.y - this.y);
	double cCross = (c.y - this.y) * (b.x - this.x);
	if (bCross > cCross) return 1;
	if (bCross < cCross) return -1;
	else return 0;
    }
}
