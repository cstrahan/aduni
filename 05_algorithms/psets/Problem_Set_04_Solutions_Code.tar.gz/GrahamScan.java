import java.util.*;

public class GrahamScan
{
    public static void main(String[] args)
    {
	Point[] points =
	{
	    new Point('A', 0, 0),
	    new Point('B', -5, -2),
	    new Point('C', -2, -1),
	    new Point('D', -6, 0),
	    new Point('E', -3.5, 1),
	    new Point('F', -4.5, 1.5),
	    new Point('G', -2.5, -5),
	    new Point('H', 1, -2.5),
	    new Point('I', 2.5, .5),
	    new Point('J', -2.2, 2.2)
		};
	convexHull(points);
    }
    
    public static void convexHull(Point[] pointsArr)
    {
	findLowestAndSwitch(pointsArr);
	sortPoints(pointsArr);
	LinkedList hull = findHull(pointsArr);
	ListIterator iter = hull.listIterator();
	System.out.println("Points in Convex Hull:");
	while (iter.hasNext())
	    {
		Point p = (Point)iter.next();
		p.printPoint();
	    }
    }
    
    public static void findLowestAndSwitch(Point[] pointsArr)
    {
	Point lowestPoint = pointsArr[0];
	int lowestIndex = 0;

	for (int i = 1; i < pointsArr.length; i++)
	    {
		double thisy = pointsArr[i].getY();
		double lowy = lowestPoint.getY();
		if (thisy < lowy)
		    {
			lowestPoint = pointsArr[i];
			lowestIndex = i;
		    }
		if (thisy == lowy)
		    {
			if (pointsArr[i].getX() < lowestPoint.getX())
			    {
				lowestPoint = pointsArr[i];
				lowestIndex = i;
			    }
		    }
	    }
	pointsArr[lowestIndex] = pointsArr[0];
	pointsArr[0] = lowestPoint;
    }

    public static void sortPoints(Point[] pointsArr)
    {
	for (int i = pointsArr.length/2; i > 0; i--)
	    heapify(pointsArr, i, pointsArr.length);
	
	int heapSize = pointsArr.length;
	for (int i = pointsArr.length - 1; i > 1; i--)
	    {
		Point temp = pointsArr[1];
		pointsArr[1] = pointsArr[i];
		pointsArr[i] = temp;
		heapSize--;
		heapify(pointsArr, 1, heapSize);
	    }
		
    }

    public static LinkedList findHull(Point[] pointsArr)
    {
	LinkedList stack = new LinkedList();
	if (pointsArr.length < 3)
	    {
		System.out.println("No convex hull - fewer than 3 points.");
		return stack;
	    }
	stack.add(pointsArr[0]);
	stack.add(pointsArr[1]);
	stack.add(pointsArr[2]);
	for (int i = 3; i < pointsArr.length; i++)
	    {
		Point c = pointsArr[i];
		Point b = (Point)stack.getLast();
		Point a = (Point)stack.get(stack.size() - 2);
		while (a.turnOrient(b, c) != -1)
		    {
			stack.removeLast();
			b = (Point)stack.getLast();
			a = (Point)stack.get(stack.size() - 2);
		    }
		stack.add(c);
	    }
	return stack;
    }

    public static void heapify(Point[] pointsArr, int i, int heapSize)
    {
	// assumes findLowestAndSwitch has been run
	Point lowPoint = pointsArr[0];
	Point iPoint = pointsArr[i];

	int left = 2*i;
	int right = 2*i + 1;
	int largest = i;
	
	if (left < heapSize)
	    {
		Point leftPoint = pointsArr[left];
		int leftOrientVal =
		    lowPoint.turnOrient(iPoint, leftPoint);
		if (leftOrientVal == -1) largest = left;
		if (leftOrientVal == 0)
		    {
			if (Point.distance(lowPoint, iPoint) <
			    Point.distance(lowPoint, leftPoint))
			    largest = left;
		    }
	    }
	if (right < heapSize)
	    {
		Point rightPoint = pointsArr[right];
		Point largestPoint = pointsArr[largest];
		int rightOrientVal =
		    lowPoint.turnOrient(largestPoint, rightPoint);
		if (rightOrientVal == -1) largest = right;
		if (rightOrientVal == 0)
		    {
			if (Point.distance(lowPoint, largestPoint) <
			    Point.distance(lowPoint, rightPoint))
			    largest = right;
		    }
	    }
	if (largest != i)
	    {
		pointsArr[i] = pointsArr[largest];
		pointsArr[largest] = iPoint;
		heapify(pointsArr, largest, heapSize);
	    }
    }
}


