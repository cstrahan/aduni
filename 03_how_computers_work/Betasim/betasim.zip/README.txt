To run Betasim:

1. Unzip Betasim.zip into a directory. Be sure to preserve the directory structure.

2. Execute:

	jview.exe /cp:p betasim.jar Betasim

* Make sure you save your work in the "work" directory, otherwise the ".include" statements will not work.